﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.txtLast = New System.Windows.Forms.TextBox()
        Me.txtFirst = New System.Windows.Forms.TextBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtPass = New System.Windows.Forms.TextBox()
        Me.txtTIM = New System.Windows.Forms.TextBox()
        Me.txtTOW = New System.Windows.Forms.TextBox()
        Me.txtTIW = New System.Windows.Forms.TextBox()
        Me.txtTOT = New System.Windows.Forms.TextBox()
        Me.txtTIT = New System.Windows.Forms.TextBox()
        Me.txtTOM = New System.Windows.Forms.TextBox()
        Me.txtTOF = New System.Windows.Forms.TextBox()
        Me.txtTIF = New System.Windows.Forms.TextBox()
        Me.txtTOTh = New System.Windows.Forms.TextBox()
        Me.txtTITh = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lblLastC = New System.Windows.Forms.Label()
        Me.lblFirstC = New System.Windows.Forms.Label()
        Me.lblIDC = New System.Windows.Forms.Label()
        Me.lblMoC = New System.Windows.Forms.Label()
        Me.lblMC = New System.Windows.Forms.Label()
        Me.lblPassC = New System.Windows.Forms.Label()
        Me.lblTC = New System.Windows.Forms.Label()
        Me.lblFrC = New System.Windows.Forms.Label()
        Me.lblFC = New System.Windows.Forms.Label()
        Me.lblThuC = New System.Windows.Forms.Label()
        Me.lblThC = New System.Windows.Forms.Label()
        Me.lblWeC = New System.Windows.Forms.Label()
        Me.lblWC = New System.Windows.Forms.Label()
        Me.lblTuC = New System.Windows.Forms.Label()
        Me.lvwStaffInfo = New System.Windows.Forms.ListView()
        Me.colLast = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colFirst = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colPass = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTIM = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTOM = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTIT = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTOT = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTIW = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTOW = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTITh = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTOTh = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTIF = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTOF = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.SuspendLayout()
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(519, 454)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(84, 44)
        Me.btnBack.TabIndex = 0
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'txtLast
        '
        Me.txtLast.Location = New System.Drawing.Point(92, 324)
        Me.txtLast.Name = "txtLast"
        Me.txtLast.Size = New System.Drawing.Size(100, 20)
        Me.txtLast.TabIndex = 2
        '
        'txtFirst
        '
        Me.txtFirst.Location = New System.Drawing.Point(92, 350)
        Me.txtFirst.Name = "txtFirst"
        Me.txtFirst.Size = New System.Drawing.Size(100, 20)
        Me.txtFirst.TabIndex = 3
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(92, 376)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(100, 20)
        Me.txtID.TabIndex = 4
        '
        'txtPass
        '
        Me.txtPass.Location = New System.Drawing.Point(92, 402)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.Size = New System.Drawing.Size(100, 20)
        Me.txtPass.TabIndex = 5
        '
        'txtTIM
        '
        Me.txtTIM.Location = New System.Drawing.Point(92, 428)
        Me.txtTIM.Name = "txtTIM"
        Me.txtTIM.Size = New System.Drawing.Size(100, 20)
        Me.txtTIM.TabIndex = 6
        Me.txtTIM.Text = "0000"
        '
        'txtTOW
        '
        Me.txtTOW.Location = New System.Drawing.Point(363, 376)
        Me.txtTOW.Name = "txtTOW"
        Me.txtTOW.Size = New System.Drawing.Size(100, 20)
        Me.txtTOW.TabIndex = 11
        Me.txtTOW.Text = "0000"
        '
        'txtTIW
        '
        Me.txtTIW.Location = New System.Drawing.Point(363, 350)
        Me.txtTIW.Name = "txtTIW"
        Me.txtTIW.Size = New System.Drawing.Size(100, 20)
        Me.txtTIW.TabIndex = 10
        Me.txtTIW.Text = "0000"
        '
        'txtTOT
        '
        Me.txtTOT.Location = New System.Drawing.Point(363, 324)
        Me.txtTOT.Name = "txtTOT"
        Me.txtTOT.Size = New System.Drawing.Size(100, 20)
        Me.txtTOT.TabIndex = 9
        Me.txtTOT.Text = "0000"
        '
        'txtTIT
        '
        Me.txtTIT.Location = New System.Drawing.Point(92, 480)
        Me.txtTIT.Name = "txtTIT"
        Me.txtTIT.Size = New System.Drawing.Size(100, 20)
        Me.txtTIT.TabIndex = 8
        Me.txtTIT.Text = "0000"
        '
        'txtTOM
        '
        Me.txtTOM.Location = New System.Drawing.Point(92, 454)
        Me.txtTOM.Name = "txtTOM"
        Me.txtTOM.Size = New System.Drawing.Size(100, 20)
        Me.txtTOM.TabIndex = 7
        Me.txtTOM.Text = "0000"
        '
        'txtTOF
        '
        Me.txtTOF.Location = New System.Drawing.Point(363, 480)
        Me.txtTOF.Name = "txtTOF"
        Me.txtTOF.Size = New System.Drawing.Size(100, 20)
        Me.txtTOF.TabIndex = 15
        Me.txtTOF.Text = "0000"
        '
        'txtTIF
        '
        Me.txtTIF.Location = New System.Drawing.Point(363, 454)
        Me.txtTIF.Name = "txtTIF"
        Me.txtTIF.Size = New System.Drawing.Size(100, 20)
        Me.txtTIF.TabIndex = 14
        Me.txtTIF.Text = "0000"
        '
        'txtTOTh
        '
        Me.txtTOTh.Location = New System.Drawing.Point(363, 428)
        Me.txtTOTh.Name = "txtTOTh"
        Me.txtTOTh.Size = New System.Drawing.Size(100, 20)
        Me.txtTOTh.TabIndex = 13
        Me.txtTOTh.Text = "0000"
        '
        'txtTITh
        '
        Me.txtTITh.Location = New System.Drawing.Point(363, 402)
        Me.txtTITh.Name = "txtTITh"
        Me.txtTITh.Size = New System.Drawing.Size(100, 20)
        Me.txtTITh.TabIndex = 12
        Me.txtTITh.Text = "0000"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 325)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 15)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Last Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(13, 351)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 15)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "First Name:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(13, 403)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 15)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "Password:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(13, 377)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(22, 15)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "ID:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(13, 481)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(69, 15)
        Me.Label6.TabIndex = 22
        Me.Label6.Text = "TI Tuesday:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(13, 455)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 15)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "TO Monday:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(13, 429)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(67, 15)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "TI Monday:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(264, 481)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 15)
        Me.Label5.TabIndex = 29
        Me.Label5.Text = "TO Friday:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(264, 455)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(56, 15)
        Me.Label9.TabIndex = 28
        Me.Label9.Text = "TI Friday:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(264, 429)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(79, 15)
        Me.Label10.TabIndex = 27
        Me.Label10.Text = "TO Thursday:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(264, 403)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(73, 15)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "TI Thursday:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(264, 377)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(93, 15)
        Me.Label12.TabIndex = 25
        Me.Label12.Text = "TO Wednesday:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(264, 351)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(87, 15)
        Me.Label13.TabIndex = 24
        Me.Label13.Text = "TI Wednesday:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(264, 325)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(75, 15)
        Me.Label14.TabIndex = 23
        Me.Label14.Text = "TO Tuesday:"
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Location = New System.Drawing.Point(519, 325)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 31)
        Me.btnAdd.TabIndex = 30
        Me.btnAdd.Text = "ADD"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'lblLastC
        '
        Me.lblLastC.AutoSize = True
        Me.lblLastC.Location = New System.Drawing.Point(660, 366)
        Me.lblLastC.Name = "lblLastC"
        Me.lblLastC.Size = New System.Drawing.Size(45, 13)
        Me.lblLastC.TabIndex = 31
        Me.lblLastC.Text = "Label01"
        Me.lblLastC.Visible = False
        '
        'lblFirstC
        '
        Me.lblFirstC.AutoSize = True
        Me.lblFirstC.Location = New System.Drawing.Point(660, 379)
        Me.lblFirstC.Name = "lblFirstC"
        Me.lblFirstC.Size = New System.Drawing.Size(45, 13)
        Me.lblFirstC.TabIndex = 32
        Me.lblFirstC.Text = "Label02"
        Me.lblFirstC.Visible = False
        '
        'lblIDC
        '
        Me.lblIDC.AutoSize = True
        Me.lblIDC.Location = New System.Drawing.Point(660, 392)
        Me.lblIDC.Name = "lblIDC"
        Me.lblIDC.Size = New System.Drawing.Size(45, 13)
        Me.lblIDC.TabIndex = 33
        Me.lblIDC.Text = "Label03"
        Me.lblIDC.Visible = False
        '
        'lblMoC
        '
        Me.lblMoC.AutoSize = True
        Me.lblMoC.Location = New System.Drawing.Point(660, 431)
        Me.lblMoC.Name = "lblMoC"
        Me.lblMoC.Size = New System.Drawing.Size(45, 13)
        Me.lblMoC.TabIndex = 36
        Me.lblMoC.Text = "Label06"
        Me.lblMoC.Visible = False
        '
        'lblMC
        '
        Me.lblMC.AutoSize = True
        Me.lblMC.Location = New System.Drawing.Point(660, 418)
        Me.lblMC.Name = "lblMC"
        Me.lblMC.Size = New System.Drawing.Size(45, 13)
        Me.lblMC.TabIndex = 35
        Me.lblMC.Text = "Label05"
        Me.lblMC.Visible = False
        '
        'lblPassC
        '
        Me.lblPassC.AutoSize = True
        Me.lblPassC.Location = New System.Drawing.Point(660, 405)
        Me.lblPassC.Name = "lblPassC"
        Me.lblPassC.Size = New System.Drawing.Size(45, 13)
        Me.lblPassC.TabIndex = 34
        Me.lblPassC.Text = "Label04"
        Me.lblPassC.Visible = False
        '
        'lblTC
        '
        Me.lblTC.AutoSize = True
        Me.lblTC.Location = New System.Drawing.Point(660, 444)
        Me.lblTC.Name = "lblTC"
        Me.lblTC.Size = New System.Drawing.Size(45, 13)
        Me.lblTC.TabIndex = 37
        Me.lblTC.Text = "Label07"
        Me.lblTC.Visible = False
        '
        'lblFrC
        '
        Me.lblFrC.AutoSize = True
        Me.lblFrC.Location = New System.Drawing.Point(711, 444)
        Me.lblFrC.Name = "lblFrC"
        Me.lblFrC.Size = New System.Drawing.Size(45, 13)
        Me.lblFrC.TabIndex = 44
        Me.lblFrC.Text = "Label14"
        Me.lblFrC.Visible = False
        '
        'lblFC
        '
        Me.lblFC.AutoSize = True
        Me.lblFC.Location = New System.Drawing.Point(711, 431)
        Me.lblFC.Name = "lblFC"
        Me.lblFC.Size = New System.Drawing.Size(45, 13)
        Me.lblFC.TabIndex = 43
        Me.lblFC.Text = "Label13"
        Me.lblFC.Visible = False
        '
        'lblThuC
        '
        Me.lblThuC.AutoSize = True
        Me.lblThuC.Location = New System.Drawing.Point(711, 418)
        Me.lblThuC.Name = "lblThuC"
        Me.lblThuC.Size = New System.Drawing.Size(45, 13)
        Me.lblThuC.TabIndex = 42
        Me.lblThuC.Text = "Label12"
        Me.lblThuC.Visible = False
        '
        'lblThC
        '
        Me.lblThC.AutoSize = True
        Me.lblThC.Location = New System.Drawing.Point(711, 405)
        Me.lblThC.Name = "lblThC"
        Me.lblThC.Size = New System.Drawing.Size(45, 13)
        Me.lblThC.TabIndex = 41
        Me.lblThC.Text = "Label11"
        Me.lblThC.Visible = False
        '
        'lblWeC
        '
        Me.lblWeC.AutoSize = True
        Me.lblWeC.Location = New System.Drawing.Point(711, 392)
        Me.lblWeC.Name = "lblWeC"
        Me.lblWeC.Size = New System.Drawing.Size(45, 13)
        Me.lblWeC.TabIndex = 40
        Me.lblWeC.Text = "Label10"
        Me.lblWeC.Visible = False
        '
        'lblWC
        '
        Me.lblWC.AutoSize = True
        Me.lblWC.Location = New System.Drawing.Point(711, 379)
        Me.lblWC.Name = "lblWC"
        Me.lblWC.Size = New System.Drawing.Size(45, 13)
        Me.lblWC.TabIndex = 39
        Me.lblWC.Text = "Label09"
        Me.lblWC.Visible = False
        '
        'lblTuC
        '
        Me.lblTuC.AutoSize = True
        Me.lblTuC.Location = New System.Drawing.Point(711, 366)
        Me.lblTuC.Name = "lblTuC"
        Me.lblTuC.Size = New System.Drawing.Size(45, 13)
        Me.lblTuC.TabIndex = 38
        Me.lblTuC.Text = "Label08"
        Me.lblTuC.Visible = False
        '
        'lvwStaffInfo
        '
        Me.lvwStaffInfo.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colLast, Me.colFirst, Me.colID, Me.colPass, Me.colTIM, Me.colTOM, Me.colTIT, Me.colTOT, Me.colTIW, Me.colTOW, Me.colTITh, Me.colTOTh, Me.colTIF, Me.colTOF})
        Me.lvwStaffInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lvwStaffInfo.FullRowSelect = True
        Me.lvwStaffInfo.GridLines = True
        Me.lvwStaffInfo.HideSelection = False
        Me.lvwStaffInfo.Location = New System.Drawing.Point(12, 12)
        Me.lvwStaffInfo.Name = "lvwStaffInfo"
        Me.lvwStaffInfo.Size = New System.Drawing.Size(776, 306)
        Me.lvwStaffInfo.TabIndex = 45
        Me.lvwStaffInfo.UseCompatibleStateImageBehavior = False
        Me.lvwStaffInfo.View = System.Windows.Forms.View.Details
        '
        'colLast
        '
        Me.colLast.Text = "Last Name"
        Me.colLast.Width = 120
        '
        'colFirst
        '
        Me.colFirst.Text = "First Name"
        Me.colFirst.Width = 120
        '
        'colID
        '
        Me.colID.Text = "ID"
        Me.colID.Width = 120
        '
        'colPass
        '
        Me.colPass.Text = "Password"
        Me.colPass.Width = 120
        '
        'colTIM
        '
        Me.colTIM.Text = "TI Monday"
        Me.colTIM.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colTIM.Width = 120
        '
        'colTOM
        '
        Me.colTOM.Text = "TO Monday"
        Me.colTOM.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colTOM.Width = 120
        '
        'colTIT
        '
        Me.colTIT.Text = "TI Tuesday"
        Me.colTIT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colTIT.Width = 120
        '
        'colTOT
        '
        Me.colTOT.Text = "TO Tuesday"
        Me.colTOT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colTOT.Width = 120
        '
        'colTIW
        '
        Me.colTIW.Text = "TI Wednesday"
        Me.colTIW.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colTIW.Width = 120
        '
        'colTOW
        '
        Me.colTOW.Text = "TO Wednesday"
        Me.colTOW.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colTOW.Width = 120
        '
        'colTITh
        '
        Me.colTITh.Text = "TI Thursday"
        Me.colTITh.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colTITh.Width = 120
        '
        'colTOTh
        '
        Me.colTOTh.Text = "TO Thursday"
        Me.colTOTh.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colTOTh.Width = 120
        '
        'colTIF
        '
        Me.colTIF.Text = "TI Friday"
        Me.colTIF.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colTIF.Width = 120
        '
        'colTOF
        '
        Me.colTOF.Text = "TO Friday"
        Me.colTOF.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colTOF.Width = 120
        '
        'frmAdd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 520)
        Me.Controls.Add(Me.lvwStaffInfo)
        Me.Controls.Add(Me.lblFrC)
        Me.Controls.Add(Me.lblFC)
        Me.Controls.Add(Me.lblThuC)
        Me.Controls.Add(Me.lblThC)
        Me.Controls.Add(Me.lblWeC)
        Me.Controls.Add(Me.lblWC)
        Me.Controls.Add(Me.lblTuC)
        Me.Controls.Add(Me.lblTC)
        Me.Controls.Add(Me.lblMoC)
        Me.Controls.Add(Me.lblMC)
        Me.Controls.Add(Me.lblPassC)
        Me.Controls.Add(Me.lblIDC)
        Me.Controls.Add(Me.lblFirstC)
        Me.Controls.Add(Me.lblLastC)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtTOF)
        Me.Controls.Add(Me.txtTIF)
        Me.Controls.Add(Me.txtTOTh)
        Me.Controls.Add(Me.txtTITh)
        Me.Controls.Add(Me.txtTOW)
        Me.Controls.Add(Me.txtTIW)
        Me.Controls.Add(Me.txtTOT)
        Me.Controls.Add(Me.txtTIT)
        Me.Controls.Add(Me.txtTOM)
        Me.Controls.Add(Me.txtTIM)
        Me.Controls.Add(Me.txtPass)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.txtFirst)
        Me.Controls.Add(Me.txtLast)
        Me.Controls.Add(Me.btnBack)
        Me.Name = "frmAdd"
        Me.Text = "Add New Member"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnBack As Button
    Friend WithEvents txtLast As TextBox
    Friend WithEvents txtFirst As TextBox
    Friend WithEvents txtID As TextBox
    Friend WithEvents txtPass As TextBox
    Friend WithEvents txtTIM As TextBox
    Friend WithEvents txtTOW As TextBox
    Friend WithEvents txtTIW As TextBox
    Friend WithEvents txtTOT As TextBox
    Friend WithEvents txtTIT As TextBox
    Friend WithEvents txtTOM As TextBox
    Friend WithEvents txtTOF As TextBox
    Friend WithEvents txtTIF As TextBox
    Friend WithEvents txtTOTh As TextBox
    Friend WithEvents txtTITh As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents btnAdd As Button
    Friend WithEvents lblLastC As Label
    Friend WithEvents lblFirstC As Label
    Friend WithEvents lblIDC As Label
    Friend WithEvents lblMoC As Label
    Friend WithEvents lblMC As Label
    Friend WithEvents lblPassC As Label
    Friend WithEvents lblTC As Label
    Friend WithEvents lblFrC As Label
    Friend WithEvents lblFC As Label
    Friend WithEvents lblThuC As Label
    Friend WithEvents lblThC As Label
    Friend WithEvents lblWeC As Label
    Friend WithEvents lblWC As Label
    Friend WithEvents lblTuC As Label
    Friend WithEvents lvwStaffInfo As ListView
    Friend WithEvents colLast As ColumnHeader
    Friend WithEvents colFirst As ColumnHeader
    Friend WithEvents colID As ColumnHeader
    Friend WithEvents colPass As ColumnHeader
    Friend WithEvents colTIM As ColumnHeader
    Friend WithEvents colTOM As ColumnHeader
    Friend WithEvents colTIT As ColumnHeader
    Friend WithEvents colTOT As ColumnHeader
    Friend WithEvents colTIW As ColumnHeader
    Friend WithEvents colTOW As ColumnHeader
    Friend WithEvents colTITh As ColumnHeader
    Friend WithEvents colTOTh As ColumnHeader
    Friend WithEvents colTIF As ColumnHeader
    Friend WithEvents colTOF As ColumnHeader
End Class
