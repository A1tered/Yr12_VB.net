﻿Public Class frmStaff

    'Name:         Zach Smith
    'Start:        12 June 2020
    'Last Updated: 12 June 2020
    'Description:  This screen will be used to record the time members come in and out of work





    'Not Complete due to time constraints




    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Dim Login As New frmLogin
        Login.Show()
        Login = Nothing
        Me.Hide()
    End Sub


















End Class